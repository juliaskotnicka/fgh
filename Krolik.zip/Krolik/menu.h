#ifndef MENU_H
#define MENU_H
#include "SFML/Graphics.hpp"

#define MAX_NUMBER 2


class Menu
{
public:
    Menu(float width, float height);
    ~Menu();

    sf::Texture background1;
    sf::Sprite  background;
    void draw(sf::RenderWindow &window);
    void up();
    void down();
    int GetPressedItem() { return selectedItemIndex; }
   void initBackground1(sf::RenderWindow &window);


private:
    int selectedItemIndex;
    sf::Font font;
    sf::Text menu[MAX_NUMBER];

};

#endif // MENU_H
