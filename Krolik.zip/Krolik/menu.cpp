#include "menu.h"
#include <SFML/Graphics.hpp>
#include <iostream>
#include <windows.h>
#include "game.h"
Menu::Menu(float width, float height)
{
    if (!font.loadFromFile("PixellettersFull.ttf"))
    {
std::cout<<"Error";
    }

    menu[0].setFont(font);
    menu[0].setString("Start");
    menu[0].setCharacterSize(60);
    menu[0].setFillColor(sf::Color::Blue);
    menu[0].setPosition(350,200);

    menu[1].setFont(font);
    menu[1].setString("Exit");
    menu[1].setCharacterSize(60);
    menu[1].setFillColor(sf::Color::Black);
    menu[1].setPosition(350,400);

    selectedItemIndex = 0;
}


Menu::~Menu()
{
}

void Menu::draw(sf::RenderWindow &window)
{
    window.draw(background);
    for (int i = 0; i < MAX_NUMBER; i++)
    {
        window.draw(menu[i]);

    }
}

void Menu::up()
{
    if (selectedItemIndex - 1 >= 0)
    {
        menu[selectedItemIndex].setFillColor(sf::Color::Black);
        selectedItemIndex--;
        menu[selectedItemIndex].setFillColor(sf::Color::Blue);
    }
}

void Menu::down()
{
    if (selectedItemIndex + 1 < MAX_NUMBER)
    {
        menu[selectedItemIndex].setFillColor(sf::Color::Black);
        selectedItemIndex++;
        menu[selectedItemIndex].setFillColor(sf::Color::Blue);
    }
}

void Menu::initBackground1(sf::RenderWindow &window)
{

        if (!this->background1.loadFromFile("bunny.jpg"))
        {
            std::cout << "error background" << "\n";
        }

        this->background.setTexture(this->background1);

}

