#ifndef GAMESTATE_H
#define GAMESTATE_H


class GameState
{
public:
    GameState();
};

#endif // GAMESTATE_H
